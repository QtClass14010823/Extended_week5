﻿#include <QCoreApplication>
#include <QSettings>

#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int i;

    // Requires root privilege only in linux
    // In windows store at "C:\ProgramData\MyOrg\MyApp.ini" file (if app is not defined "C:\ProgramData\MyOrg.ini")
    // In linux store at "/etc/xdg/MyOrg/MyApp.ini" file (if app is not defined "/etc/xdg/MyOrg.ini")
    QSettings settings(QSettings::IniFormat, QSettings::SystemScope, "MyOrg", "MyApp");

    // Does not require administrative/root privileges
    // In windows store at "C:\Users\root\AppData\Roaming\MyOrg\MyApp.ini" file (if app is not defined "C:\Users\root\AppData\Roaming\MyOrg.ini")
    // In linux store at "/home/user/.config/MyOrg/MyApp.ini" file (if app is not defined "/home/user/.config/MyOrg.ini")
    //QSettings settings(QSettings::IniFormat, QSettings::UserScope, "MyOrg", "MyApp");

    i = settings.value("value").toInt();
    cout << "Value is: " << i << endl;

    cout << "Enter new value: ";
    cin >> i;
    settings.setValue("value", i);

    return 0;
}
