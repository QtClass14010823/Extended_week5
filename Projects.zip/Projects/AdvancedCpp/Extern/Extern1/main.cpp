extern int var;

int main(void)
{
    return 0;
}

// This program compiles successfully. Here var is declared only.
// Notice var is never used so no problems arise.
