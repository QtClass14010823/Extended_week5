﻿/*
#include <iostream>
using namespace std;

int main()
{
    int x = 10;
    int* ptr = &x;
    int&* ptr1 = ptr;
}

Output:
./18074365-ebdc-4b13-81f2-cfc42bb4b035.cpp: In function 'int main()':
./18074365-ebdc-4b13-81f2-cfc42bb4b035.cpp:8:11: error: cannot declare pointer to 'int&'
     int&* ptr1 = ptr;
 */

/*
#include <iostream>
using namespace std;

int main()
{
    int* ptr = NULL;
    int& ref = *ptr;
    cout << ref << '\n';
}

Output:
timeout: the monitored command dumped core
/bin/bash: line 1:    34 Segmentation fault      timeout 15s ./372da97e-346c-4594-990f-14edda1f5021 < 372da97e-346c-4594-990f-14edda1f5021.in
*/

#include <iostream>
using namespace std;

int& fun()
{
    int x = 10;
    return x;
}

int main()
{
    fun() = 30;
    cout << fun() << endl;
    return 0;
}

// Output: 0 or 10