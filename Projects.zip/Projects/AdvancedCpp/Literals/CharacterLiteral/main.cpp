#include <stdio.h>

int main()
{
    // constant char literal
    const char charVal = 'A';

    printf("Character Literal: %c\n",
        charVal);
    return 0;
}
